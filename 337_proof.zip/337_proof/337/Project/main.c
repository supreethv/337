#include <at89c5131.h>
#include "lcd.h"		//Header file with LCD interfacing functions
#include "serial.c"	//C file with UART interfacing functions

sbit out_pin = P0^0;

void lcd_input(void)
{
	 lcd_cmd(0x80);
	 lcd_write_string("Input Please.");
}	

void lcd_invalid(void)
{
	 lcd_cmd(0x80);
	 lcd_write_string("Invalid Input");
	 msdelay(2000);
	 lcd_cmd(0x01);
}	

void buzz(void){
	int i;
	for(i=0;i<=249;i++)
	{
		out_pin=1;
		msdelay(2);
		out_pin=0;
		msdelay(2);
	}
	msdelay(1000);
}


//Main function
void main(void)
{
	unsigned char ch=0;
	int row;
	int column;
	//Initialize port P1 for output from P1.7-P1.4
	P1 = 0x0F;
	
	//Call initialization functions
	lcd_init();
	uart_init();
	while(1)
	{
			lcd_input();
			//Receive a character
			ch = receive_char();
			REN=0;
			if(ch>='a' && ch<='z')
			{
				lcd_cmd(0x01);
				if(ch>'k')
				{
					ch=ch-98;
				}
				else if(ch=='k')
				{
					ch='c';
					ch=ch-97;
				}
				else
				{
					ch=ch-97;
				}
				row=(ch/5)+1;
				column=(ch%5)+1;
				while(row!=0)
				{
					buzz();
					row=row-1;
				}
				msdelay(1000);
				while(column!=0)
				{
					buzz();
					column=column-1;
				}
			}
			else
			{
				lcd_invalid();
				lcd_input();
			}
			msdelay(1000);
			REN=1;
	}
}